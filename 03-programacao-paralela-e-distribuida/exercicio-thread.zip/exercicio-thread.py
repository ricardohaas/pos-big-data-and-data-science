import time
import threading 
import logging
import math
import random
import os

"""
O numero a ser verificado eh dividido em N partes para ser processado por varias threads

Ao encontrar um divisor, a thread escreve ele em um arquivo

Em cada thread ao identificar que o arquivo existe ou terminar os itens a serem processados,
ela eh finalizada

No final da execucao o processo principal verifica se existe o arquivo, indicando que um divisor foi encontrado

"""

class MyThread(threading.Thread):
    def __init__(self, number_test, number_start, number_end):
        self.number_test = float(number_test)
        self.number_start = number_start
        self.number_end = number_end
        super(MyThread, self).__init__()

    def run(self):
        for i in range(self.number_start, self.number_end ):
            if(os.path.exists('divisor.txt')):
                print('Divisor ja encontrado, thread ')
                break

            print("\r\ntesting:",format(i),format(self.number_start))
            if (self.number_test / i ).is_integer():
                f = open("divisor.txt","w+")
                f.write('Divisor encontrado: '+ format(i))
                print('Pelo menos um divisor encontrado pela thread: '+format(i))
                return True
        return False            

def checkSomeThreadIsAlive(threadList):
    for i in range(len(thread_list)):
        if(thread_list[i].isAlive()):
            return True
    return False

def checkResult():
    if(os.path.exists('divisor.txt')):
        return True
    return False


if(os.path.exists('divisor.txt')):
    os.remove('divisor.txt') 

#testes

#teste numero nao primo
number_test = 10000000

#teste numero primo
#number_test = 10000019

thread_number = 3
thread_list = []
sqrt_number = math.sqrt(number_test)
number_sqrt = int(sqrt_number) + 1
number_part = int(number_sqrt/thread_number) + 1

for i in range (thread_number):
    startNumber = number_part * i if number_part * i > 1 else 2
    endNumber = number_part * (i+1)
    print("\r\nPartes:",format(startNumber),format(endNumber))
    thread = MyThread(number_test, startNumber, endNumber)
    thread_list.append(thread)
    thread.start()

for thread in thread_list:
    thread.join()

if(os.path.exists('divisor.txt')):
    print('Encontrou um divisor')
    f = open("divisor.txt","r")
    contents =f.read()
    print(contents)
    print(format(number_test)+" nao eh primo")
else:
    print(format(number_test)+' eh primo')



